INTERFACE_COMPILE_DEFINITIONS
-----------------------------

.. |property_name| replace:: compile definitions
.. |command_name| replace:: :command:`target_compile_definitions`
.. |PROPERTY_INTERFACE_NAME| replace:: ``INTERFACE_COMPILE_DEFINITIONS``
.. |PROPERTY_LINK| replace:: :prop_tgt:`COMPILE_DEFINITIONS`
.. include:: INTERFACE_BUILD_PROPERTY.txt
