IMPORTED_CXX_MODULES_COMPILE_OPTIONS
------------------------------------

.. versionadded:: 3.28

List of options to pass to the compiler for this ``IMPORTED`` target's C++
modules.

.. include:: ../command/OPTIONS_SHELL.txt
